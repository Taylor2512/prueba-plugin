# Resumen de riesgos

- active recipient color must drive catalog icons
- existing schema ownerColor must remain immutable after recipient switch
- Moveable/Selecto resize/rotate must not collide with selection, inline edit, context menu, comments, or shortcuts
- snapshot round-trip must preserve recipient color, owner, rotation and designer metadata
- externalForms must consume sisad-pdfme Form/Viewer and avoid manual schema renderer duplication
- ContentCustomForm must remain business host; sisad-pdfme must own canvas/runtime details
- CSS must stay scoped to .sisad-pdfme-root and not break geometry handles
