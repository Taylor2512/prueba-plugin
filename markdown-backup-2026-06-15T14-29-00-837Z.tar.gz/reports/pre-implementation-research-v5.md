# Investigación previa v5

## Fuentes consideradas

- Documentación consolidada del proyecto con arquitectura `.ai`, agentes, reglas, prompts, tests y docs.
- Snapshot de código unificado con Designer, Form, Viewer, Generator, schemas estándar, command bus, Moveable/Selecto y tests.
- Capturas y grabaciones comparadas con patrones de DocuSign.
- Incidentes detectados: page gap, schemas pesados, overlap, shortcuts rotos, selección múltiple, checkboxGroup/radioGroup y DetailView.

## Conclusión

El proyecto requiere pasar de fixes locales a contratos por proceso. Esta arquitectura v5 agrega behavior contracts, reglas de interacción, diseño inspirado en DocuSign/Wix, distribución multi-PDF/multi-página y matrices de regresión.
