# Análisis completo — SISAD PDFME

Generado: `2026-06-01T18:47:53Z`

## Fuentes analizadas

| Fuente | Métrica |
|---|---:|
| Código unificado | 510 archivos |
| Markdown unificado | 323 archivos |
| CSS unificado | 6 archivos |
| Líneas de código consolidado | 104352 |
| Líneas CSS consolidadas | 13735 |
| Líneas docs sisad-pdfme | 24037 |
| Líneas referencia Inverneg | 16626 |

## Módulos de código detectados

- `tests/playwright`: 11 archivos
- `tests/unit`: 83 archivos
- `src/sisad-pdfme/ui`: 121 archivos
- `src/sisad-pdfme/schemas`: 56 archivos
- `src/sisad-pdfme/pdf-lib`: 154 archivos
- `src/sisad-pdfme/generator`: 5 archivos
- `src/sisad-pdfme/converter`: 8 archivos
- `src/sisad-pdfme/shared`: 13 archivos
- `src/sisad-pdfme/common`: 11 archivos
- `src/sisad-pdfme/collaboration`: 3 archivos
- `src/sisad-pdfme/externalForms`: 1 archivos
- `src/features/pdfcomponent`: 18 archivos

## CSS detectado

- `src/sisad-pdfme/ui/styles/sisad-pdfme-global.css`
- `src/features/pdfcomponent/labRoutes.css`
- `src/sisad-pdfme/ui/styles/canvas-interactions.css`
- `src/sisad-pdfme/ui/styles/sisad-pdfme-demo.css`
- `src/sisad-pdfme/ui/styles/sisad-pdfme-runtime.css`
- `src/sisad-pdfme/ui/styles/tokens.css`

## Objetivos deducidos

- active recipient color must drive catalog icons
- existing schema ownerColor must remain immutable after recipient switch
- Moveable/Selecto resize/rotate must not collide with selection, inline edit, context menu, comments, or shortcuts
- snapshot round-trip must preserve recipient color, owner, rotation and designer metadata
- externalForms must consume sisad-pdfme Form/Viewer and avoid manual schema renderer duplication
- ContentCustomForm must remain business host; sisad-pdfme must own canvas/runtime details
- CSS must stay scoped to .sisad-pdfme-root and not break geometry handles

## Decisión de arquitectura

La arquitectura v3 combina:

1. El modelo `.ai/docs/handoff/tests/providers` de Inverneg.
2. La especialización del fork `sisad-pdfme`.
3. La necesidad actual de recipient colors + transform controls.
4. La futura integración con `ContentCustomForm` y `externalForms`.
5. La reducción de duplicidad entre runtime, host y documentación.
