# Inventario de módulos

- `tests/playwright`: 11
- `tests/unit`: 83
- `src/sisad-pdfme/ui`: 121
- `src/sisad-pdfme/schemas`: 56
- `src/sisad-pdfme/pdf-lib`: 154
- `src/sisad-pdfme/generator`: 5
- `src/sisad-pdfme/converter`: 8
- `src/sisad-pdfme/shared`: 13
- `src/sisad-pdfme/common`: 11
- `src/sisad-pdfme/collaboration`: 3
- `src/sisad-pdfme/externalForms`: 1
- `src/features/pdfcomponent`: 18
